@echo off
setlocal
set "GRADLE_VERSION=8.14.3"
set "GRADLE_HOME=%USERPROFILE%\.gradle\manual-gradle\gradle-%GRADLE_VERSION%"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
set "BASE=%USERPROFILE%\.gradle\manual-gradle"
if not exist "%BASE%" mkdir "%BASE%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $v='%GRADLE_VERSION%'; $b='%BASE%'; $z=Join-Path $b ('gradle-'+$v+'-bin.zip'); if (!(Test-Path $z)) { Invoke-WebRequest ('https://services.gradle.org/distributions/gradle-'+$v+'-bin.zip') -OutFile $z }; Expand-Archive -Force $z $b"
if errorlevel 1 exit /b 1
:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
