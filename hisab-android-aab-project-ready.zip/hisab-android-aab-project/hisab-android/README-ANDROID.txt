Android Studio میں اسی فولڈر کو کھولیں۔ مکمل Build، signing، GitHub Actions اور Google Play checklist کے لیے ZIP کے root میں README.md دیکھیں۔
