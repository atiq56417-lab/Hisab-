# مارکیٹ حساب کتاب — Android اور Web

یہ ریپوزٹری آپ کی فراہم کردہ ZIP سے مرتب کی گئی ہے۔ Android ایپ میں اصل حساب کتاب والا HTML/JavaScript انٹرفیس مقامی Android WebView کے اندر چلتا ہے۔

## پروجیکٹ کی ترتیب

- `hisab-android/` — Android Studio کا اصل پروجیکٹ
- `hisab-web/` — براؤزر میں چلنے والا الگ Web ورژن
- `docs/privacy-policy.html` — رازداری کی پالیسی کا مسودہ؛ اشاعت سے پہلے رابطہ ای میل درج کریں
- `play-store-assets/app-icon-512.png` — Play Store کے لیے 512×512 آئیکن
- `.github/workflows/android.yml` — GitHub Actions کے ذریعے خودکار Build

## Android کی تکنیکی ترتیبات

- Application ID: `com.hisab.market` (Play Console میں دستیابی چیک کریں؛ اگر پہلے کسی نے لیا ہوا ہو تو پہلی اشاعت سے پہلے تبدیل کریں)
- `compileSdk`: 36
- `targetSdk`: 36 — 17 نومبر 2026 کو نئی ایپس کے لیے Google Play کی API 36 شرط کے مطابق
- `minSdk`: 29 (Android 10 یا بعد کا ورژن)
- Java: 17
- Android Gradle Plugin: 8.11.1
- Gradle: 8.14.3

## اپنے کمپیوٹر پر APK اور AAB بنانا

1. Android Studio کا تازہ مستحکم ورژن اور Android SDK Platform 36 انسٹال کریں۔
2. Android Studio میں `hisab-android` فولڈر کھولیں اور Gradle Sync مکمل ہونے دیں۔
3. پہلے Debug APK بنا کر فون یا Emulator پر مکمل ٹیسٹ کریں:

   ```bash
   ./gradlew assembleDebug
   ```

   Windows پر:

   ```bat
   gradlew.bat assembleDebug
   ```

   فائل: `app/build/outputs/apk/debug/app-debug.apk`

4. Play Store کے لیے **signed** AAB بنائیں۔ Android Studio میں:
   `Build > Generate Signed App Bundle / APK > Android App Bundle`
5. نئی Upload key بنائیں، پاس ورڈ اور `.jks` فائل محفوظ رکھیں۔ یہ فائل GitHub پر ہرگز اپلوڈ نہ کریں۔
6. Release AAB کا راستہ عموماً:
   `app/build/outputs/bundle/release/app-release.aab`

کمانڈ لائن سے release بنانا ہو تو پہلے signing environment variables مقرر کریں:
`ANDROID_KEYSTORE_FILE`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`
پھر `./gradlew bundleRelease assembleRelease` چلائیں۔ ان متغیرات کے بغیر release outputs unsigned ہوں گے، Play Console پر اپلوڈ نہیں کیے جا سکتے۔

## GitHub پر اپلوڈ اور خودکار Build

1. اس ZIP کو Extract کریں۔
2. Extract شدہ فولڈر کے **تمام اندرونی مواد** (خصوصاً `.github` پوشیدہ فولڈر سمیت) نئے GitHub repository میں اپلوڈ کریں۔ صرف `hisab-android` فولڈر اپلوڈ نہ کریں، ورنہ GitHub Actions workflow نہیں چلے گا۔
3. `main` یا `master` برانچ پر Push کریں۔ GitHub کے `Actions` ٹیب میں Android build چل جائے گا۔
4. کامیاب Build کے بعد workflow کے `Artifacts` سے Debug APK اور Release APK/AAB حاصل کریں۔ اگر signing secrets فراہم نہ کیے گئے ہوں تو Release APK/AAB unsigned ہوں گے۔
5. GitHub Actions میں signed AAB بنانے کے لیے Repository Settings → Secrets and variables → Actions میں یہ چار Secrets بنائیں:
   - `ANDROID_KEYSTORE_BASE64` — اپنی `.jks` فائل کا Base64 متن
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEY_PASSWORD`

   Keystore کی اصل فائل اور پاس ورڈ کسی کے ساتھ شیئر نہ کریں۔

## Google Play پر اشاعت سے پہلے لازمی کام

یہ پروجیکٹ کی طرف سے تیار کردہ تکنیکی بنیاد ہے، Google Play کی منظوری کی ضمانت نہیں۔ Play Console میں آپ کو خود یہ کام مکمل کرنے ہوں گے:

- ایپ کا منفرد Package/Application ID یقینی بنائیں۔
- حقیقی فونز پر تمام بنیادی فیچرز، بیک اپ/ری اسٹور، پرنٹ/PDF اور اردو UI ٹیسٹ کریں۔
- `docs/privacy-policy.html` میں اپنا فعال رابطہ ای میل درج کریں اور اسے عوامی HTTPS URL پر شائع کریں (مثلاً GitHub Pages)۔ اسی URL کو Play Console میں دیں۔
- Data safety فارم ایپ کے اصل رویے کے مطابق پُر کریں؛ اس سورس میں ڈیٹا مقامی طور پر محفوظ ہوتا ہے، لیکن اشاعت سے پہلے تمام SDKs اور شامل شدہ اجزاء کی بھی جانچ کریں۔
- Store listing میں کم از کم مطلوبہ Screenshots، 512×512 آئیکن، مختصر/مکمل تفصیل، Support رابطہ اور دیگر مطلوبہ اثاثے فراہم کریں۔ Feature graphic بھی Play Console کی موجودہ ہدایات کے مطابق بنائیں۔
- Content rating questionnaire، Ads declaration، Target audience، App access اور دیگر Play Console سوالنامے درست پُر کریں۔
- اگر آپ کا ذاتی Developer account نیا ہے تو اس اکاؤنٹ پر لاگو Closed testing کی شرط بھی پوری کریں۔
- ہر نئی ریلیز پر `versionCode` بڑھائیں۔

## ڈیٹا اور رازداری

ایپ کا موجودہ انٹرفیس WebView کے `localStorage` میں ریکارڈ محفوظ کرتا ہے۔ ایپ کے ڈیٹا ٹیب سے JSON بیک اپ ڈاؤن لوڈ کیا جا سکتا ہے۔ ایپ اَن انسٹال کرنے یا ایپ ڈیٹا صاف کرنے سے مقامی ریکارڈ ضائع ہو سکتے ہیں؛ باقاعدہ بیک اپ رکھیں۔ Privacy Policy ایک مسودہ ہے، اسے اپنی حقیقی رابطہ معلومات کے ساتھ شائع کرنا ضروری ہے۔

## موجودہ حدود / جانچ

اس ماحول میں Android SDK/Gradle toolchain دستیاب نہیں تھی، اس لیے یہاں سے APK/AAB compile کر کے device test یا Play Console pre-launch report چلانا ممکن نہیں ہوا۔ Gradle، manifest، آئیکنز، GitHub workflow اور ہدایات مرتب کی گئی ہیں؛ حتمی Build اور حقیقی ڈیوائس ٹیسٹ آپ کے Android Studio یا GitHub Actions میں لازمی ہیں۔
